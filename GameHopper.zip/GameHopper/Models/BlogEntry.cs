namespace GameHopper.Models
{
    public class BlogEntry
    {
        public Guid Id { get; set; }
        public string Content {get; set;}

        
    }
}