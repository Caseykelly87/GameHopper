﻿using GameHopper.Models;

namespace GameHopper;

public class Player : User
    {
    
        public Player(string name) : base(name)
        {
        }
    }
